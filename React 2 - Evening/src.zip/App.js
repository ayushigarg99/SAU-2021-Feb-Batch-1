import logo from './logo.svg';
import './App.css';
import Router1 from './routes'


function App() {
  return (
    <Router1></Router1>
  );
}

export default App;
