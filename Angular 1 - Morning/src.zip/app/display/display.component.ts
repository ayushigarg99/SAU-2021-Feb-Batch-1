import { Component } from '@angular/core';

@Component({
  selector: 'app-display',
  template: `
    <input #newWord
      (keyup.enter)="addWord(newWord.value)"
      (blur)="addWord(newWord.value); newWord.value='' ">

    <button (click)="addWord(newWord.value)">Add</button>


    <p *ngFor="let word of words">{{ word.wordName }} || {{ word.clickedAt }}</p>
  `
})
export class DisplayComponent {
  
  words: Array<any>=[];
  addWord(newWord: string) {
    if (newWord) {
      this.words.push({wordName: newWord, clickedAt: new Date()});
    }
  }
}
